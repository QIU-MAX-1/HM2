 
w=32
x=350
y=8190
z=2045
import time
import subprocess  
i=subprocess.call("color 08", shell=True)
i=subprocess.call("mode con: cols=50 lines=30", shell=True)

i=subprocess.call("cls", shell=True)
time.sleep(2)



i=subprocess.call("systeminfo", shell=True)
time.sleep(1.5)
i=subprocess.call("cls", shell=True)


print('-'*100)
time.sleep(0.1)
print('1.恒铭 中文DOS')
time.sleep(0.1)
print('2.PYTHON开发环境')
time.sleep(0.1)
print('-'*100)
os=input('请输入您要启动的系统(1/2),输入EXIT退出>>>')

if os=='EXIT' or os=='exit':
      exit('pythonshell')

elif os == 'good' or os=='GOOD':
      i=subprocess.call("cls", shell=True)
      while True:
            print('      ******     ******')
            print('    **********   **********')
            print('  ************* *************')
            print(' *****************************')
            print('*****************************')
            print('*****************************')
            print('***************************')
            print('  ***********************')
            print('     *******************')
            print('        ***************')
            print('          ***********')
            print('             *******')
            print('                ***')
            print('                 *')

            i=subprocess.call("color 0c", shell=True)
            print(' Thanks ')
            time.sleep(1000)
            i=subprocess.call("cls", shell=True)
            
            
            

while os!='1' and os!='2':
      i=subprocess.call("cls", shell=True)
      print('-'*100)
      time.sleep(0.1)
      print('1.[恒铭]中文DOS')
      time.sleep(0.1)
      print('2.PYTHON开发环境')
      time.sleep(0.1)
      print('-'*100)
      os=input('请输入您要启动的系统(1/2),输入EXIT退出>>> ')



i=subprocess.call("cls", shell=True)
a=35*2+20

b=1
if os == 'good' or os=='GOOD':
      i=subprocess.call("cls", shell=True)
      while True:
            print('      ******     ******')
            print('    **********   **********')
            print('  ************* *************')
            print(' *****************************')
            print('*****************************')
            print('*****************************')
            print('***************************')
            print('  ***********************')
            print('     *******************')
            print('        ***************')
            print('          ***********')
            print('             *******')
            print('                ***')
            print('                 *')

 
            print(' Thanks ')
            time.sleep(1000)
            i=subprocess.call("cls", shell=True)
a=0
print(' _         ____               _____    _____   _   _    _____  ')  
print('| |       / __ \      /\     |  __ \  |_   _| | \ | |  / ____|') 
print('| |      | |  | |    /  \    | |  | |   | |   |  \| | | |  __ ')    
print('| |      | |  | |   / /\ \   | |  | |   | |   | . ` | | | |_ |')   
print('| |____  | |__| |  / ____ \  | |__| |  _| |_  | |\  | | |__| |')   
print('|______|  \____/  /_/    \_\ |_____/  |_____| |_| \_|  \_____|')
print('\n'*2,'正在启动系统......(',a,'%) \n')
print('▓'*a)
time.sleep(1.5)
i=subprocess.call("cls", shell=True)
while a<100:
    a=a+5
    if a>100:
        a=100
    
    

    
    print(' _         ____               _____    _____   _   _    _____  ')
    
    print('| |       / __ \      /\     |  __ \  |_   _| | \ | |  / ____|')
    
    print('| |      | |  | |    /  \    | |  | |   | |   |  \| | | |  __ ')
    
    print('| |      | |  | |   / /\ \   | |  | |   | |   | . ` | | | |_ |')
    
    print('| |____  | |__| |  / ____ \  | |__| |  _| |_  | |\  | | |__| |')
    
    print('|______|  \____/  /_/    \_\ |_____/  |_____| |_| \_|  \_____|')
    
    print('\n'*2,'正在启动系统......(',a,'%) \n')
    print('▓'*a)
    
    time.sleep(0.25)
    i=subprocess.call("cls", shell=True)
    
    
    

if os=='1':

    time.sleep(0.5)
    i=subprocess.call("color 06", shell=True)
    i=subprocess.call("cls", shell=True)
    
    
    print(' _    _   __  __   _____     ____     _____') 
    print('| |  | | |  \/  | |  __ \   / __ \   / ____|')
    print('| |__| | | \  / | | |  | | | |  | | | (___ ') 
    print('|  __  | | |\/| | | |  | | | |  | |  \___ \ ')
    print('| |  | | | |  | | | |__| | | |__| |  ____) |')
    print('|_|  |_| |_|  |_| |_____/   \____/  |_____/ ')
                                                     
                                                     
    print('\n\n [恒铭]中文DOS V1.0 详细信息请输入(TYPE VER) \n\n')
                       
               
    i=subprocess.call("CMD/K", shell=True)
    



if os=='2':
    i=subprocess.call("cls", shell=True)
    i=subprocess.call("color 06", shell=True)
    
    i=subprocess.call("PY", shell=True)
    

    
